testSub('/work/subs/fedor.srt')
