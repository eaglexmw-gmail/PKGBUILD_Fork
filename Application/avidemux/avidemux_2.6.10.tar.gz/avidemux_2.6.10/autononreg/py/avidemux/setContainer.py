#PY  <- Needed to identify#
#--automatically built--
#--Project: /tmp/foobar.py

adm=Avidemux()
#** Video **
# 01 videos source 
adm.loadVideo("/work/samples/avi/2mn.avi")
#** Muxer **
adm.setContainer("AVI")

#End of script
