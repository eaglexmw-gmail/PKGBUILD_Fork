gui=Gui()
gui.displayError("oops","something went wrong!")
