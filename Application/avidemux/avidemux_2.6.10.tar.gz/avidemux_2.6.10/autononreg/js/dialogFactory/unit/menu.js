//AD  <- These first 4 characters need to be the first 4 characters to identify the ECMAScript file to Avidemux
print("Testing factory Menu");
	admTestFacMenu();
print("Testing factory Menu");
/* End of test
*/
