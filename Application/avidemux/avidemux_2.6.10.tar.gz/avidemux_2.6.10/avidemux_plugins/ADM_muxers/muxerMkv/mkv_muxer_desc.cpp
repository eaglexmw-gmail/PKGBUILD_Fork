const ADM_paramList mkv_muxer_param[]={
 {"forceDisplayWidth",offsetof(mkv_muxer,forceDisplayWidth),"bool",ADM_param_bool},
 {"displayWidth",offsetof(mkv_muxer,displayWidth),"uint32_t",ADM_param_uint32_t},
{NULL,0,NULL}
};
