const ADM_paramList avi_muxer_param[]={
 {"odmlType",offsetof(avi_muxer,odmlType),"uint32_t",ADM_param_uint32_t},
{NULL,0,NULL}
};
