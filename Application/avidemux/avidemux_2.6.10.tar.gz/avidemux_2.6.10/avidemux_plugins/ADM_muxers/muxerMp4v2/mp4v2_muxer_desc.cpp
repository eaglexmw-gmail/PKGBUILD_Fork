const ADM_paramList mp4v2_muxer_param[]={
 {"optimize",offsetof(mp4v2_muxer,optimize),"uint32_t",ADM_param_uint32_t},
 {"add_itunes_metadata",offsetof(mp4v2_muxer,add_itunes_metadata),"uint32_t",ADM_param_uint32_t},
{NULL,0,NULL}
};
