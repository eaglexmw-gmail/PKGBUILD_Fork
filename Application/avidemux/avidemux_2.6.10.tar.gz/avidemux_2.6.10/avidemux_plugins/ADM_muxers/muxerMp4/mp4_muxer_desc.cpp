const ADM_paramList mp4_muxer_param[]={
 {"muxerType",offsetof(mp4_muxer,muxerType),"uint32_t",ADM_param_uint32_t},
 {"useAlternateMp3Tag",offsetof(mp4_muxer,useAlternateMp3Tag),"bool",ADM_param_bool},
{NULL,0,NULL}
};
