
void print_channels ();
double get_chan_frequency(const char *nameornumber, char *optional_namebuf) ;
