#ifndef PROXY_TYPE_H
#define PROXY_TYPE_H
#ifndef _MSC_VER
#include <stdint.h>
#else
typedef  unsigned char uint8_t;
typedef  unsigned int uint32_t;
#endif
#endif

